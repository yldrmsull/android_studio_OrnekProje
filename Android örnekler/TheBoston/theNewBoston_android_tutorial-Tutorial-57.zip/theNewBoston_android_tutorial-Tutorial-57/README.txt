Hi all,

I'm  just learning android from the awesome tutorials made by Travis (available for FREE at http://thenewboston.org/list.php?cat=6) and decided to code them in hand. Just pushing them to this repo if anyone needs them.

One interesting point, I'll make a commit after every tutorial! So you can browse the snapsot of each tutorial by selecting a download from https://github.com/shafiul/theNewBoston_android_tutorial/tags

Cool, huh? (The initial commit begins with Tutorial 10, though).

You can also browse-through the codes of different tutorials online.

Regards,
Shafiul
http://shafiul.users.sf.net