package net.sourceforge.users.shafiul;

import android.app.Activity;
import android.os.Bundle;

public class Data extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		// custom
		setContentView(R.layout.get);
	}

}
